// ----------------------------------- FUNCIONES -----------------------------------
// Función que obtiene el color de un pixel dentro de una imagen JPEG
// https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Pixel_manipulation_with_canvas
function distanciaEuclideana(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
}

function calificar(distancias) {
    let fitness = 0;
    for (let distancia of distancias) {
        if (distancia < 1) {
            fitness = 1;
        } else if (distancia < 10) {
            fitness += 0.75;
        } else if (distancia < 30) {
            fitness += 0.5;
        } else if (distancia < 50) {
            fitness += 0.25;
        } else if (distancia < 100) {
            fitness += 0.1;
        } else {
            fitness += 0.01;
        }
    }
    return fitness;
}

function obtenerColorPixel(canvas, x, y) {
    return canvas.ucharAt(y, x);
}

function obtenerPuntosValidos(img, tamanoImg) {
    let pixeles = [];
    for (x = 0; x < tamanoImg; x++) {
        for (y = 0; y < tamanoImg; y++) {
            let color = img.ucharPtr(y,x);
            if (color[0] != 255 && color[1] != 255 && color[2] != 255) {
                pixeles.push([x, y]);
            }
        }
    }
    return pixeles;
}

function puntosIntermedios(p1, p2) {
    let lstPuntos = [];
    let x1 = p1.x;
    let y1 = p1.y;
    let x2 = p2.x;
    let y2 = p2.y;
    // Diferencia absoluta en X y Y. Estas diferencias representan las longitudes de la recta en las direcciones X e Y
    let dx = Math.abs(x2 - x1);
    let dy = Math.abs(y2 - y1);
    // Determina la dirección de la recta. Si x1 es menor que x2, sx se establece en 1, de lo contrario se establece en -1.Lo mismo para sy
    let sx = (x1 < x2) ? 1 : -1;
    let sy = (y1 < y2) ? 1 : -1;
    // Error es la cantidad de veces que la recta se desvía de la ubicación ideal. Se inicializa en 0
    let err = dx - dy;
    let largoLstPuntos = dx + dy;
    for (let i = 0; i < largoLstPuntos+1; i++) {
        lstPuntos.push(new cv.Point(x1, y1));
        if ((x1 == x2) && (y1 == y2)) break;
        // e2 es el error de dos veces. Si es mayor que -dy, la recta se desvía menos en la dirección y (x1, y1 + 1); de lo contrario, la recta se desvía más en la dirección y (x1 + 1, y1 + 1)
        let e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
    return lstPuntos;
}

function obtenerPatron(lstPuntos, tamCambio) {
    let patron = [];
    let xInicial = lstPuntos[0].x;
    let yInicial = lstPuntos[0].y;
    let x = 0;
    let y = 0;
    for (let i = 1; i < tamCambio; i++) {
        x = lstPuntos[i].x - xInicial;
        y = lstPuntos[i].y - yInicial;
        patron.push([x, y]);
    }
    return patron;
}

function obtenerFinal(tamCambio, lista_puntos) {
    let final_lPuntos = lista_puntos[lista_puntos.length - 1];
    let puntos_finales = []
    let patron = obtenerPatron(lista_puntos, tamCambio);
    for (let i = 0; i < patron.length; i++) {
        let x = final_lPuntos.x + patron[i][0];
        let y = final_lPuntos.y + patron[i][1];
        if (x < 0 || y < 0 || x > 255 || y > 255) break;
        let punto = new cv.Point(x, y);
        puntos_finales.push(punto);
    }
    return puntos_finales;
}

class Individuo {
    constructor(tamLinea, cromosoma=null) {
        if (cromosoma == null) {
            this.cromosoma = this.generarCromosoma(tamLinea);
        } else {
            this.cromosoma = cromosoma;
        }
        this.linea = this.cromosoma[0];
        this.anchoLinea = this.cromosoma[1];
        this.fitness = null;
    }

    dibujarIndividuo(canvas) {
        let p1 = this.linea[0];
        let p2 = this.linea[this.linea.length-1];
        cv.line(canvas, p1, p2, [255, 255, 255, 255], this.anchoLinea);
        //for (let i = 0; i < this.linea.length-1; i++) {
        //    let p1 = this.linea[i];
        //    let p2 = this.linea[i+1];
        //    cv.line(canvas, p1, p2, [255, 255, 255, 255], this.anchoLinea);
        //}
    }

    generarCromosoma(tamLinea) {
        let puntos = []
        for (let i=0; i < 2; i++) {
           let x = Math.floor(Math.random() * tamLinea);
           let y = Math.floor(Math.random() * tamLinea);
           puntos.push(new cv.Point(x, y));
        }
        let anchoLinea = 2; //Math.floor(Math.random() * 5) + 1;
        let linea = puntosIntermedios(puntos[0], puntos[1])
        return [linea, anchoLinea];
    }

    cruzar(otro, tamLinea) {
        // let nuevo_indiv = new Individuo(tamLinea);

        // let actual_p1 = this.linea[0];
        // let actual_p2 = this.linea[this.linea.length-1];
        // let otro_p1 = otro.linea[0];
        // let otro_p2 = otro.linea[otro.linea.length-1];

        // let x_p1 = (actual_p1.x+otro_p1.x) / 2;
        // let y_p1 = (actual_p1.y+otro_p1.y) / 2;
        // let x_p2 = (actual_p2.x+otro_p2.x) / 2;
        // let y_p2 = (actual_p2.y+otro_p2.y) / 2;

        // let p1 = new cv.Point(x_p1, y_p1);
        // let p2 = new cv.Point(x_p2, y_p2);
        // let anchoLinea = (this.anchoLinea + otro.anchoLinea) / 2;
        // if (anchoLinea < 1) anchoLinea = 1;

        // nuevo_indiv.linea = puntosIntermedios(p1, p2);
        // nuevo_indiv.anchoLinea = anchoLinea;
        // nuevo_indiv.cromosoma = [nuevo_indiv.linea, nuevo_indiv.anchoLinea];
        // return nuevo_indiv;

        let nueva_linea = [];

        let largo_actual = this.linea.length;
        let largo_otro = otro.linea.length;
        let largo_medio = Math.floor((largo_actual + largo_otro) / 2);
        let punto = null;

        for (let i = 0; i < largo_medio; i++) { // indv actual = 100puntos, indv otro = 50puntos
            if (i % 2 == 0) {
                punto = this.linea[Math.floor(Math.random() * largo_actual)];
            } else {
                punto = otro.linea[Math.floor(Math.random() * largo_otro)];
            }
            nueva_linea.push(punto);
        }

        let anchoLinea = (this.anchoLinea + otro.anchoLinea) / 2;
        if (anchoLinea < 1) anchoLinea = 1;
        let cromosoma = [nueva_linea, anchoLinea];
        let nuevo_indiv = new Individuo(tamLinea, cromosoma);
        return nuevo_indiv;
    }

    mutar(tamLinea) {
        // // Definicion de variables
        // let nuevo_indiv = new Individuo(tamLinea, this.cromosoma);
        // let pocentaje_cambio = Math.random() * (0.2000 - 0.6000) + 0.6000;
        // let aumenta_disminuye = Math.floor(Math.random() * 2); // 0: aumenta, 1: disminuye
        // let largo_actual = nuevo_indiv.linea.length;
        // let tamCambio = Math.floor(largo_actual*pocentaje_cambio);
        // let puntos = [];
        // let fin = [];

        // // Mutaciones de largo
        // if (aumenta_disminuye == 1) { // Disminuye
        //     puntos = nuevo_indiv.linea.slice(tamCambio, largo_actual);
        // } else { // Aumenta
        //     fin = obtenerFinal(tamCambio, nuevo_indiv.linea)
        //     puntos = nuevo_indiv.linea.concat(fin);
        // }
        
        // // Mutaciones de ancho
        // let cambio_ancho = Math.floor(Math.random() * 3); // 0: no cambia, 1: aumenta, 2: disminuye
        // if (cambio_ancho == 1) {
        //     nuevo_indiv.anchoLinea = nuevo_indiv.anchoLinea + 1;
        // } else if (cambio_ancho == 2) {
        //     nuevo_indiv.anchoLinea = nuevo_indiv.anchoLinea - 1;
        // } else {
        //     nuevo_indiv.anchoLinea = nuevo_indiv.anchoLinea;
        // }
        // if (nuevo_indiv.anchoLinea < 1) nuevo_indiv.anchoLinea = 1;

        // nuevo_indiv.linea = puntos;
        // nuevo_indiv.cromosoma = [nuevo_indiv.linea, nuevo_indiv.anchoLinea];
        // return nuevo_indiv;

        let nuevo_indiv = new Individuo(tamLinea, this.cromosoma);
        let pocentaje_cambio = Math.random() * (0.5000 - 0.2000) + 0.2000; // Random de 0.2 a 0.5
        let largo_actual = nuevo_indiv.linea.length;

        // Mutaciones de largo
        for (let i = 0; i < largo_actual*pocentaje_cambio; i++) {
            let punto = nuevo_indiv.linea[i];

            let x = punto.x + Math.floor(Math.random() * 3) - 1; // x = 3 --> 3, 4, 5
            let y = punto.y + Math.floor(Math.random() * 3) - 1; // y = 6 --> 6, 7, 8
            //console.log(punto, x, y);

            if (x < 0 || y < 0 || x > 255 || y > 255) continue;
            nuevo_indiv.linea[i] = new cv.Point(x, y);
        }

        // Mutaciones de ancho
        let cambio_ancho = Math.floor(Math.random() * 3); // 0: no cambia, 1: aumenta, 2: disminuye
        if (cambio_ancho == 1) {
            nuevo_indiv.anchoLinea = nuevo_indiv.anchoLinea + 1;
        } else if (cambio_ancho == 2) {
            nuevo_indiv.anchoLinea = nuevo_indiv.anchoLinea - 1;
        } else {
            nuevo_indiv.anchoLinea = nuevo_indiv.anchoLinea;
        }
        if (nuevo_indiv.anchoLinea < 1) nuevo_indiv.anchoLinea = 1;

        nuevo_indiv.cromosoma = [nuevo_indiv.linea, nuevo_indiv.anchoLinea];
        return nuevo_indiv;

    }

    calcularFitness(canvas, puntosValidos) {
        if (this.fitness != null) {
            return this.fitness;
        }
        let fitness = 0;
        let lstPuntos = this.linea;
        let distancias = [];
        for (let punto2 of lstPuntos) {
            let color = obtenerColorPixel(canvas, punto2.x, punto2.y);
            if (color == 0) {
                continue;
            }
            let minDistancia = Infinity;
            for (let punto1 of puntosValidos) {
                let distancia = distanciaEuclideana(punto1[0], punto1[1], punto2.x, punto2.y);
                minDistancia = Math.min(minDistancia, distancia);
            }
            distancias.push(minDistancia);
        }
        fitness = calificar(distancias);
        this.fitness = fitness;
        return fitness;
    }

    // calcularFitness(img) {
    //     let fitness = 0;
    //     let lstPuntos = this.linea;
    //     for (let i = 0; i < this.linea.length-1; i++) {
    //         let punto = lstPuntos[i];
    //         const pixel = img.ucharAt(punto.x, punto.y);
    //         //console.log(pixel);
    //         if (pixel[0] != 255 && pixel[1] != 255 && pixel[2] != 255) {
    //             fitness += 1;
    //         }
    //     }
    //     this.fitness = fitness;
    //     return fitness;
    // }
}

class Poblacion {
    constructor(tamPoblacion, tamLinea, numGen, poblacion = null) {
        this.mejor_fitness = null;
        this.fitness_promedio = null;
        if (poblacion == null) {
            this.poblacion = [];
            this.numGen = 0;
            for (let i = 0; i < tamPoblacion; i++) {
                this.poblacion.push(new Individuo(tamLinea));
            }
        } else {
            this.numGen = numGen+1;
            this.poblacion = poblacion;
        }
    }

    dibujarPoblacion(canvas, tamPoblacion) {
        for (let i = 0; i < tamPoblacion; i++) {
            this.poblacion[i].dibujarIndividuo(canvas);
        }
    }

    ordenarPoblacion() {
        this.poblacion.sort(function (a, b) {
            return b.fitness - a.fitness;
        });
    }

    calcularFitness(img, puntosValidos, tamPoblacion) {
        let promedio = 0;
        for (let i = 0; i < tamPoblacion; i++) {
            let fitness = this.poblacion[i].calcularFitness(img, puntosValidos);
            promedio += fitness;
        }
        this.ordenarPoblacion();
        this.mejor_fitness = this.poblacion[0].fitness;
        this.fitness_promedio = promedio / tamPoblacion;
        return this.poblacion;
    }

    nuevaPoblacion(canvas, tamLinea, puntosValidos, tamPoblacion, porcentajeSeleccion, porcentajeMutacion, porcentajeCombinar, img) {
        let poblacion = this.poblacion;
        // Selección 20%
        let seleccion = poblacion.slice(0, Math.floor(tamPoblacion * porcentajeSeleccion));
        
        let indice = 0;
        let seleccion2 = [];
        seleccion2.concat(seleccion);
        while (seleccion2.length < tamPoblacion) {
            if (indice == seleccion.length) {
                indice = 0;
            }
            seleccion2.push(seleccion[indice]);
            indice++;
        }
        // Mutación 30%
        let mutacion = [];
        for (let i = 0; i < Math.floor(tamPoblacion * porcentajeMutacion); i++) {
            let individuo = seleccion2[i];
            mutacion.push(individuo.mutar(tamLinea));
        }
        // Combinación 50%
        // ES NECESARIO MODIFICAR cruzar() PARA QUE NO SE REPITAN LOS PUNTOS CUANDO LA POBLACION ES PEQUEÑA
        let combinacion = [];
        for (let i = 0; i < Math.floor(tamPoblacion * porcentajeCombinar); i++) {
            let individuo1 = seleccion2[i*2];
            let individuo2 = seleccion2[i*2+1];
            combinacion.push(individuo1.cruzar(individuo2, tamLinea));
        }
        // Nueva población
        poblacion = seleccion.concat(mutacion, combinacion);
        let nuevaPoblacion = new Poblacion(tamPoblacion, tamLinea, this.numGen, poblacion);
        nuevaPoblacion.dibujarPoblacion(canvas, tamPoblacion);
        nuevaPoblacion.calcularFitness(img, puntosValidos, tamPoblacion);
        return nuevaPoblacion;
    }
}