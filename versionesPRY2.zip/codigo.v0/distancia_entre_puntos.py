# Programa que recibe un punto con coordenadas X e Y. Recibe un segundo punto y determina si la distancia entre el segundo punto y el primero es menor a x unidades.
import math
def distancia_euclideana(point1, point2):
    x1, y1 = point1
    x2, y2 = point2
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def distancia_mas_cercana(lista1, lista2):
    distancias_mas_cercanas = []
    for punto2 in lista2:
        min_distancia = float('inf')
        for punto1 in lista1:
            distancia = distancia_euclideana(punto1, punto2)
            min_distancia = min(min_distancia, distancia)
        distancias_mas_cercanas.append(min_distancia)
    return distancias_mas_cercanas

def calificar(distancias):
    fitness = 0
    for distancia in distancias:
        if distancia < 10: # Cerca
            fitness += 1
        elif distancia < 20: # Medio
            fitness += 0.5
        elif distancia < 30: # Lejos
            fitness += 0.25
        elif distancia < 40: # Muy lejos
            fitness += 0.1
    return fitness

lista1 = [[50,80], [20,90], [23,76], [11,87]]
lista2 = [[56,90],[23,67],[12,23], [100, 100], [50, 50], [0, 0]]

distancias = distancia_mas_cercana(lista1, lista2)
resultado = calificar(distancias)
print(resultado)
