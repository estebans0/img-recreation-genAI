# Algoritmo genetico que debe converger a una lista de números específica -> [1, 2, 3, 4, 5, 6, 7, 8, 9]

import random
objetivo = [1, 2, 3, 4, 5, 6, 7, 8, 9]

class Individuo:
    def __init__(self, cromosoma):
        if cromosoma == None:
            self.cromosoma = [random.randint(1, 9) for _ in range(9)]
        else:
            self.cromosoma = cromosoma
        self.fitness = self.calcularFitness()
    
    def calcularFitness(self):
        fitness = 0
        for i in range(9):
            if self.cromosoma[i] == objetivo[i]:
                fitness += 1
        return fitness
    
    def cruzar(self, otro):
        hijo = []
        for i in range(9):
            if random.random() < 0.5:
                hijo.append(self.cromosoma[i])
            else:
                hijo.append(otro.cromosoma[i])
        return Individuo(hijo)
    
    def mutar(self):
        for i in range(9):
            if random.random() < 0.15:
                self.cromosoma[i] = random.randint(1, 9)
        self.fitness = self.calcularFitness()

class Poblacion:
    def __init__(self, poblacionInicial = None):
        if poblacionInicial == None:
            self.individuos = [Individuo(None) for _ in range(100)]
        else:
            self.individuos = poblacionInicial
        self.individuos.sort(key = lambda x: x.fitness, reverse = True)

    def seleccionar(self, porcentajeSeleccion):
        seleccionados = []
        largo = len(self.individuos)
        for i in range(int(largo * porcentajeSeleccion)):
            seleccionados.append(self.individuos[i])
        return seleccionados
    
    def nuevaGeneracion(self, porcentajeSeleccion, porcentajeCruzar, porcentajeMutar):
        seleccionados = self.seleccionar(porcentajeSeleccion)
        nuevaPoblacion = []
        for i in range(len(self.individuos)):
            padre = random.choice(seleccionados)
            madre = random.choice(seleccionados)
            hijo = padre.cruzar(madre)
            hijo.mutar()
            nuevaPoblacion.append(hijo)
        return Poblacion(nuevaPoblacion)

poblacion = Poblacion()
generacion = 0
while poblacion.individuos[0].fitness < 9:
    generacion += 1
    poblacion = poblacion.nuevaGeneracion(0.2, 0.5, 0.15)
    print("Generación: ", generacion, " - Mejor fitness: ", poblacion.individuos[0].fitness, " - Mejor individuo: ", poblacion.individuos[0].cromosoma)
