// -------------------------- FUNCIONES DEL ALGORITMO GENÉTICO --------------------------
// Generar los puntos aleatorios
function generarPuntos() {
    let puntos = [];
    for (i = 0; i < tamPoblacion*2; i++) {
        let x = Math.floor(Math.random() * tamanoImg);
        let y = Math.floor(Math.random() * tamanoImg);
        puntos.push(new cv.Point(x, y));
    }
    return puntos;
}

// Generar las lineas a partir de los puntos
function generarLineas(puntos) {
    let lineas = [];
    for (i = 0; i < tamPoblacion; i++) {
        let p1 = puntos[i*2];
        let p2 = puntos[i*2+1];
        lineas.push([p1, p2]);
    }
    return lineas;
}

// Dibujar las lineas en el canvas
function dibujarLineas(indiv, lineas) {
    for (i = 0; i < tamPoblacion; i++) {
        anchoLinea = Math.floor(Math.random() * 5) + 1;
        cv.line(indiv, lineas[i][0], lineas[i][1], [255, 255, 255, 255], anchoLinea)
    }
}

// Obtener la imagen del canvas. Se usará para el fitness
function obtenerImgCanvas() {
    let imgCanvas = document.getElementById('canvasOutput').toDataURL('image/jpeg');
    return imgCanvas;
}

// Función de fitness. Se compara la imagen original con la imagen del canvas usando el algoritmo de diferencia de imágenes
function fitness() {
    let imgOriginal = imgElement.src;
    let imgCanvas = obtenerImgCanvas();
    console.log(imgOriginal)
    console.log(imgCanvas)
}

// Función que dados 2 puntos con direcciones X e Y, calcula todos los puntos intermedios entre ellos
// Se basa en el algoritmo de Bresenham para dibujar lineas: https://www.javatpoint.com/computer-graphics-bresenhams-line-algorithm
function puntosIntermedios(p1, p2) {
    let lstPuntos = [];
    let x1 = p1.x;
    let y1 = p1.y;
    let x2 = p2.x;
    let y2 = p2.y;
    // Diferencia absoluta en X y Y. Estas diferencias representan las longitudes de la recta en las direcciones X e Y
    let dx = Math.abs(x2 - x1);
    let dy = Math.abs(y2 - y1);
    // Determina la dirección de la recta. Si x1 es menor que x2, sx se establece en 1, de lo contrario se establece en -1.Lo mismo para sy
    let sx = (x1 < x2) ? 1 : -1;
    let sy = (y1 < y2) ? 1 : -1;
    // Error es la cantidad de veces que la recta se desvía de la ubicación ideal. Se inicializa en 0
    let err = dx - dy;
    while (true) {
        lstPuntos.push(new cv.Point(x1, y1));
        if ((x1 == x2) && (y1 == y2)) break;
        // e2 es el error de dos veces. Si es mayor que -dy, la recta se desvía menos en la dirección y (x1, y1 + 1); de lo contrario, la recta se desvía más en la dirección y (x1 + 1, y1 + 1)
        let e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
    return lstPuntos;
}

function obtenerPatron(lstPuntos, agregado) {
    let patron = [];
    let xInicial = lstPuntos[0].x;
    let yInicial = lstPuntos[0].y;
    for (i = 0; i < agregado; i++) {
        let x = lstPuntos[i].x - xInicial;
        let y = lstPuntos[i].y - yInicial;
        patron.push([x, y]);
    }
    return patron;
}

function obtenerPuntoFinal(indiceCorte, largo, lista_puntos) {
    let final_lPuntos = lista_puntos[largo - 1];
    let puntos_anteriores = lista_puntos.slice(0, indiceCorte);
}

// Función que dada una lista de lineas obtiene los puntos que las conforman
function obtenerPuntos(lineas) {
    let puntos = [];
    for (i = 0; i < lineas.length; i++) {
        let p1 = lineas[i][0];
        let p2 = lineas[i][1];
        let puntosInter = puntosIntermedios(p1, p2);
        puntos.push(puntosInter);
    }
    return puntos;
}

// Función que obtiene el color de un pixel dentro de una imagen JPEG
// https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Pixel_manipulation_with_canvas
function obtenerColorPixel(img, x, y) {
    let canvas = document.createElement('canvas');
    let ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    let pixel = ctx.getImageData(x, y, 1, 1);
    let datos = pixel.data;
    let rgba = [datos[0], datos[1], datos[2]];
    return rgba;
}

// Función que dadas 2 imagenes obtiene el color de cada pixel
function obtenerPixelesImgs(img1, img2, tamanoImg){
    for (i=0; i < tamanoImg; i++){
        for (j=0; j < tamanoImg; j++){
            let color1 = obtenerColorPixel(img1, i, j);
            let color2 = obtenerColorPixel(img2, i, j);
            console.log(color1, color2)
        }
    }
}
