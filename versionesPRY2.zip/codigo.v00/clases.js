// ----------------------------------- FUNCIONES -----------------------------------
// Función que obtiene el color de un pixel dentro de una imagen JPEG
// https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Pixel_manipulation_with_canvas
function obtenerColorPixel(img, x, y) {
    let canvas = document.createElement('canvas');
    let ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    let pixel = ctx.getImageData(x, y, 1, 1);
    let datos = pixel.data;
    let rgba = [datos[0], datos[1], datos[2]];
    return rgba;
}

function puntosIntermedios(p1, p2) {
    let lstPuntos = [];
    let x1 = p1.x;
    let y1 = p1.y;
    let x2 = p2.x;
    let y2 = p2.y;
    // Diferencia absoluta en X y Y. Estas diferencias representan las longitudes de la recta en las direcciones X e Y
    let dx = Math.abs(x2 - x1);
    let dy = Math.abs(y2 - y1);
    // Determina la dirección de la recta. Si x1 es menor que x2, sx se establece en 1, de lo contrario se establece en -1.Lo mismo para sy
    let sx = (x1 < x2) ? 1 : -1;
    let sy = (y1 < y2) ? 1 : -1;
    // Error es la cantidad de veces que la recta se desvía de la ubicación ideal. Se inicializa en 0
    let err = dx - dy;
    let largoLstPuntos = dx + dy;
    for (let i = 0; i < largoLstPuntos+1; i++) {
        lstPuntos.push(new cv.Point(x1, y1));
        if ((x1 == x2) && (y1 == y2)) break;
        // e2 es el error de dos veces. Si es mayor que -dy, la recta se desvía menos en la dirección y (x1, y1 + 1); de lo contrario, la recta se desvía más en la dirección y (x1 + 1, y1 + 1)
        let e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
    return lstPuntos;
}

function obtenerPatron(lstPuntos, agregado) {
    let patron = [];
    let xInicial = lstPuntos[0].x;
    let yInicial = lstPuntos[0].y;
    for (let i = 0; i < agregado; i++) {
        let x = lstPuntos[i].x - xInicial;
        let y = lstPuntos[i].y - yInicial;
        patron.push([x, y]);
    }
    return patron;
}

function obtenerPuntoFinal(indiceCorte, largo, lista_puntos, aumenta_disminuye, agregado) {
    let final_lPuntos = lista_puntos[largo - 1];
    let puntos_anteriores = lista_puntos.slice(0, indiceCorte);
    if (aumenta_disminuye == 1) { // Disminuye
        return final_lPuntos;
    } else { // Aumenta
        let patron = obtenerPatron(lista_puntos, agregado);
        for (let i = 0; i < patron.length; i++) {
            let x = final_lPuntos.x + patron[i][0];
            let y = final_lPuntos.y + patron[i][1];
            let punto = new cv.Point(x, y);
            puntos_anteriores.push(punto);
        }
        return puntos_anteriores[puntos_anteriores.length - 1];
    }
}

class Individuo {
    constructor(indiv, cromosoma=null) {
        if (cromosoma == null) {
            this.cromosoma = this.generarCromosoma(indiv);
        } else {
            this.cromosoma = cromosoma;
        }
        this.cant_genes = this.cromosoma[0];
        this.anchoLinea = this.cromosoma[1];
        this.fitness = null;
    }

    generarCromosoma(indiv) {
        let puntos = []
        for (let i=0; i < 2; i++) {
           let x = Math.floor(Math.random() * tamanoImg) - 1;
           let y = Math.floor(Math.random() * tamanoImg) - 1;
           puntos.push(new cv.Point(x, y));
        }
        let anchoLinea = 2; //Math.floor(Math.random() * 5) + 1
        //let linea = cv.line(indiv, puntos[0], puntos[1], [255, 255, 255, 255], anchoLinea)
        cv.line(indiv, puntos[0], puntos[1], [255, 255, 255, 255], anchoLinea);
        let cant_genes = puntosIntermedios(puntos[0], puntos[1])
        return [cant_genes, anchoLinea];
    }

    cruzar(otro, indiv) {
        let nuevo_indiv = new Individuo(indiv);

        let actual_p1 = this.cant_genes[0]; // p1 del padre
        let actual_p2 = this.cant_genes[this.cant_genes.length-1]; // p2 del padre
        let otro_p1 = otro.cant_genes[0]; // p1 de la madre
        let otro_p2 = otro.cant_genes[otro.cant_genes.length-1]; // p2 de la madre

        let x_p1 = actual_p1.x - otro_p1.x / 2; // media entre p1 del padre y p1 de la madre para la x
        let y_p1 = actual_p1.y - otro_p1.y / 2; // media entre p1 del padre y p1 de la madre para la y
        let x_p2 = actual_p2.x - otro_p2.x / 2; // media entre p2 del padre y p2 de la madre para la x
        let y_p2 = actual_p2.y - otro_p2.y / 2; // media entre p2 del padre y p2 de la madre para la y

        let p1 = new cv.Point(x_p1, y_p1);
        let p2 = new cv.Point(x_p2, y_p2);
        let anchoLinea = (this.anchoLinea + otro.anchoLinea) / 2;

        nuevo_indiv.cant_genes = puntosIntermedios(p1, p2);
        nuevo_indiv.anchoLinea = anchoLinea;
        nuevo_indiv.cromosoma = [nuevo_indiv.cant_genes, nuevo_indiv.anchoLinea];
        return nuevo_indiv;
    }

    mutar(indiv) {
        let nuevo_indiv = new Individuo(indiv, this.cromosoma);

        let pocentaje_cambio = 0.4;
        let porcentaje_ancla = 1-pocentaje_cambio;
        let aumenta_disminuye = Math.floor(Math.random() * 2); // 0: aumenta, 1: disminuye
        let largo_actual = this.cant_genes.length;
        let agregado = largo_actual*pocentaje_cambio;

        let indiceCorte = Math.round(largo_actual - largo_actual*porcentaje_ancla)
        let ancla = this.cant_genes[indiceCorte];
        let fin = obtenerPuntoFinal(indiceCorte, largo_actual, this.cant_genes, aumenta_disminuye, agregado)
        
        let cambio_ancho = Math.floor(Math.random() * 3); // 0: no cambia, 1: aumenta, 2: disminuye
        let ancho = 0;

        if (cambio_ancho == 1) {
            ancho = this.anchoLinea + 1;
        } else if (cambio_ancho == 2) {
            ancho = this.anchoLinea - 1;
        } else {
            ancho = this.anchoLinea;
        }

        nuevo_indiv.cant_genes = puntosIntermedios(ancla, fin);
        return nuevo_indiv;
    }

    calcularFitness(img) {
        // Falta calcular el fitness usando el ancho de la linea
        let fitness = 0;
        let lstPuntos = this.cant_genes.slice(0, this.cant_genes.length-31); // Habia un error de que añadia 31 puntos extra
        for (let i=0; i < lstPuntos.length; i++){
            let color1 = obtenerColorPixel(img, lstPuntos[i].x, lstPuntos[i].y);
            if (color1[0] != 255 && color1[1] != 255 && color1[2] != 255) {
                fitness += 1;
            }
        }
        this.fitness = fitness;
        return fitness;
    }
}

class Poblacion {
    constructor(indiv, tamPoblacion, poblacion = null) {
        this.mejor_fitness = null;
        if (poblacion == null) {
            this.poblacion = [];
            for (let i = 0; i < tamPoblacion; i++) {
                this.poblacion.push(new Individuo(indiv));
            }
        } else {
            this.poblacion = poblacion;
            this.ordenarPoblacion();
        }
    }

    ordenarPoblacion() {
        this.poblacion.sort(function (a, b) {
            return b.fitness - a.fitness;
        });
    }

    calcularFitness(img) {
        for (let i = 0; i < this.poblacion.length; i++) {
            this.poblacion[i].calcularFitness(img);
        }
        this.ordenarPoblacion();
        this.mejor_fitness = this.poblacion[0].fitness;
        return this.poblacion;
    }

    nuevaPoblacion(tamPoblacion, porcentajeSeleccion, porcentajeMutacion, porcentajeCombinar, indiv, img) {
        let poblacion = this.calcularFitness(img);
        // Selección 20%
        let seleccion = poblacion.slice(0, Math.floor(tamPoblacion * porcentajeSeleccion));
        let indice = 0;
        let seleccion2 = [];
        seleccion2.concat(seleccion);
        while (seleccion2.length < tamPoblacion) {
            if (indice == seleccion.length) {
                indice = 0;
            }
            seleccion2.push(seleccion[indice]);
            indice++;
        }
        // Mutación 30%
        let mutacion = [];
        for (let i = 0; i < Math.floor(tamPoblacion * porcentajeMutacion); i++) {
            let individuo = seleccion2[i];
            mutacion.push(individuo.mutar(indiv));
        }
        // Combinación 50%
        let combinacion = [];
        for (let i = 0; i < Math.floor(tamPoblacion * porcentajeCombinar); i++) {
            let individuo1 = seleccion2[i*2];
            let individuo2 = seleccion2[i*2+1];
            combinacion.push(individuo1.cruzar(individuo2, indiv));
        }
        // Nueva población
        let nuevaPoblacion = seleccion.concat(mutacion, combinacion);
        let nueva = new Poblacion(indiv, tamPoblacion, nuevaPoblacion);
        nueva.calcularFitness(img);
        return nueva;
    }
}